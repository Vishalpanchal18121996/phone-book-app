import React from "react"

export const SubscriberCountContext = React.createContext();
